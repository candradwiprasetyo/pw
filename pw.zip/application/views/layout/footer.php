
   

    <!-- JavaScripts -->
    <script src="<?= base_url() ?>assets/js/jquery.min.js"></script>
   <!-- <script src="https://maps.googleapis.com/maps/api/js"></script>
   <script src="js/custom-map.js"></script>
   
    --><script src="<?= base_url() ?>assets/js/bootstrap.min.js"></script>
    <script src="<?= base_url() ?>assets/js/jquery.parallax-1.1.3.js"></script>
    <script src="<?= base_url() ?>assets/js/owl.carousel.js"></script>
    <script src="<?= base_url() ?>assets/js/jquery.fancybox.pack.js"></script>
    <script src="<?= base_url() ?>assets/js/backstretch.js"></script>
    <script src="<?= base_url() ?>assets/js/wow.min.js"></script>
    <script src="<?= base_url() ?>assets/js/masonry.pkgd.min.js"></script>
    <script src="<?= base_url() ?>assets/js/isotope.pkgd.min.js"></script>
    
    <!--  skill bar  -->
    <script src="<?= base_url() ?>assets/js/skill-bar.js"></script>
    
    <!-- link -->
    <script src="<?= base_url() ?>assets/js/modernizr.custom.js"></script>
    
    <script src="<?= base_url() ?>assets/js/function.js"></script>

    <script src="<?= base_url() ?>assets/js/custom.js"></script>

    <!-- clock -->
    <script src="<?= base_url() ?>assets/js/clock/clock.js" type="text/javascript"></script>
    
    <!-- popmodal -->
    <script src="<?= base_url() ?>assets/js/popmodal/popModal.js" type="text/javascript"></script>

  </body>
</html>
