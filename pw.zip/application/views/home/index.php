<?php

include 'homepage/style_config.php';
include 'homepage/navbar.php';
include 'homepage/banner.php';
include 'homepage/about.php';
include 'homepage/service.php';
include 'homepage/portofolio_new.php';
include 'homepage/pricing.php';
include 'homepage/contact.php';
include 'homepage/footer.php';

?>

