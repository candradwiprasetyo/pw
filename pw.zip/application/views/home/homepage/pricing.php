<script>
        $(document).ready(function (){
            $("#click_pricing").click(function (){
               $("html, body").animate({ scrollTop: $("#contact").offset().top }, "slow"); return false;
              
            });
        });
</script>
<!-- pricing section BEGIN  -->
    <section class="pricing" id="pricing">
      <div class="background_pricing">
      <div class="container">
        <br>
        <div class="title text-center wow animated fadeInDown"><h1>Pricing <strong>Table</strong></h1></div>
        
        
       

        <div class="col-md-4 col-md-offset-4">
          <div class="pricing-table active wow animated fadeInUp" data-wow-delay="0.1s">
            <div class="header">
              <h3>RECOMMENDED</h3></div>
            <div class="price"><span class="textbold">NEGOTIABLE</span></div>
            <div class="list">
              <ul>
                <li><span class="textbold">Have a <strong>Awesome Project ?</strong> </span></li>
                <li><span class="textbold">Need creative <strong>help ?</strong> </span></li>
                <li><span class="textbold">Or want to make the <strong>Team ?</strong></span> </li>
                <li><span class="textbold">And wants to change the <strong>WORLD ?</strong> </span></li>
                <li><span class="textbold"></span></li>
                <li><span class="notice">Dont waste ur time !</span></li>
              </ul>
              <button id="click_pricing" class="def-btn">Get In Touch</button>
            </div>
          </div>
        </div>

       
     

      </div>
    </div>
    </section>
    <!-- pricing section END  -->