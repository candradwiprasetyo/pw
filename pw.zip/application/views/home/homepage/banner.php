 
    <script>
        $(document).ready(function (){
            $("#click").click(function (){
               $("html, body").animate({ scrollTop: 700 }, "medium");
  return false;
            });
        });
    </script>
<!-- banner section BEGIN -->

<div class="navbar-inverse_new"></div>

    <section class="banner" id="home">
      <div class="overlay"></div>

      <div class="banner-content">

        
        <div class="container">
          <!--<div class="home_img">

          </div>
          -->
          <div class="col-md-12">

            <div class="tooltip tooltip-west">
              <span class="tooltip-item"></span>
              <span class="tooltip-content"><div class="face_inhouse"></div>

                Welcome to my house :) <br> <button id="click" class="button_inhouse">Enter My House</button></span>
              
            </div>
            <!--
            <div class="title">
            	<div class="icon_logo"></div>
              <h1 class="wow">
               Hi. I'am CANDRA
              </h1>
            </div>
            <div class="subtitle">
              <p>
I'm a Web Programmer & UI Designer based in Surabaya, East Java, Indonesia. <br>If you have a project or creative need that I can help with,<br>
- please get in touch -
 </p>
            </div>
            <div class="buttons">
              <a href="#about_page" class="def-btn"><strong>Know Me Better</strong></a>
            </div>
            -->

            
          
            
          </div>
        </div><!-- /.container -->
      </div><!-- /.banner-content -->
       
    </section><!-- /.banner -->
    
    <!-- banner section END -->