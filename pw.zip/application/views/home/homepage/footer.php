
 <!-- footer section START  -->
    <section class="footer">
      <div class="container">
        <div class="col-md-12 col-sm-12">
        
          © Copyright 2015 All right reserved. Designed by Candra Dwi Prasetyo
        </div>
        
      </div><!--/.container -->
    </section>
    <!-- footer section END  -->