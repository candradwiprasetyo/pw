<!-- testimonial section BEGIN-->
  
<section class="update text-center" id="update">
      
    <div class="container"> 
        <div class="title text-center wow animated fadeInDown"><h1>Do You Want to get <strong>updates</strong> ?</h1></div> 
         

        <div class="col-md-8 col-md-offset-2">
          <div class="footer-form">
           	<form action="" enctype="multipart/form-data" method="POST" name="form_update"  onsubmit="return call_update()">
             
              <div class="col-md-8  wow animated fadeInLeft" data-wow-delay="0.4s">
                <input type="email" class="form-control" placeholder="Your Email" name="i_email">
              </div>
             
              <div class="col-md-4 button-container wow animated fadeInRight" data-wow-delay="0.8s">
             
                                                    <button class="submit-btn def-btn">SAVE</button>
                                            
              
              </div>
            </form>
            </div>
        
      </div>
      </div>
      
    </section><!--/.testimonial -->
    <!-- testimonial section END-->