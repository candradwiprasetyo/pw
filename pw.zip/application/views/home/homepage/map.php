 <!-- map section START  -->
    <section class="map">
      <div class="map-title ">
        <div class="container wow animated fadeInLeft">
          <h1>Visit My <strong>Office</strong></h1>
        </div>
      </div>
     <div class=" wow animated fadeInRight">
      <div class="map">
			<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d3957.14843598542!2d112.722456!3d-7.337221999999998!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xbca94fff6072fb67!2sElkabumi+Caraka+Daya.+PT!5e0!3m2!1sen!2sus!4v1403453170137" 
			width="100%" height="300" frameborder="0" style="border:0"></iframe>
</div>
     </div>
    </section>
    <!-- map section END  -->