   <!-- testimonial section BEGIN-->
    <section class="testimonial text-center" id="testimonial">
      <div class="overlay"></div>
      
      <div id="testimonial-carousel" class="carousel slide" data-ride="carousel">
     
        <div class="container wow animated fadeInUp" data-wow-delay="0s">
          <div class="carousel-inner">
         
           
            <div class="item active">
             <div class="col-md-2 col-md-offset-1 title text-center">
           <img src="images/candramelon.png" alt="img01" class="img_about" />
          </div>
          <div class="col-md-8 title text-center">
              <div class="text">
                " Nullam rhoncus suscipit mauris, sit amet suscipit nisi eleifend et. Lorem Ipsum dolor sit amet, consectetur adipiscing elit. Nullam rhoncus suscipit mauris, sit amet suscipit nisi   eleifend et consectetur adipiscing elit. "
              </div>
              <div class="name">
                <span class="textbold">Johny Doe</span>, CEO of Rancabentang
              </div>
            </div>
            </div>

            <div class="item">
               <div class="col-md-2 col-md-offset-1 title text-center">
           <img src="images/candramelon.png" alt="img01" class="img_about" />
          </div>
          <div class="col-md-8 title text-center">
              <div class="text">
                " Nullam rhoncus suscipit mauris, sit amet suscipit nisi eleifend et. Lorem Ipsum dolor sit amet, consectetur adipiscing elit. Nullam rhoncus suscipit mauris, sit amet suscipit nisi   eleifend et consectetur adipiscing elit. "
              </div>
              <div class="name">
                <span class="textbold">Johny Doe</span>, CEO of Rancabentang
              </div>
            </div>
            </div><!--/.item -->
            
          </div><!--/.carousel-inner -->
        </div><!--/.container -->

        <!-- Controls -->
        <a class="left carousel-control wow animated fadeIn" href="#testimonial-carousel" role="button" data-slide="prev" data-wow-delay="1s">
          <div class="control-circle left"><i class="fa fa-angle-left"></i></div>
        </a>
        <a class="right carousel-control wow animated fadeIn" href="#testimonial-carousel" role="button" data-slide="next" data-wow-delay="1s">
          <div class="control-circle right"><i class="fa fa-angle-right"></i></div>
        </a>
      </div><!--/.testimonial-carousel -->
    </section><!--/.testimonial -->
    <!-- testimonial section END-->