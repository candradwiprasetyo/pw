<section class="skill_bar" id="skill_bar">
                
<div class="container">
<div class="col-md-12 text-center wow animated fadeInDown">
<div class="title"><h1>My <strong>Skill</strong></h1></div>
</div>
						<div class="row">

							<div class="col-md-6 text wow animated fadeInLeft">
							<div class="item_frame">
								<section>
									<div class="skill_title">PHP</div>
									<div class="progress-wrap1 progress" data-progress-percent1="80">
									  80 %<div class="progress-bar1 progress"></div>

									</div>
									
									
								</section>
							</div>
						  </div>
                          
                          <div class="col-md-6 text wow animated fadeInRight">
							<div class="item_frame">
								<section>
									<div class="skill_title">MySQL</div>
									<div class="progress-wrap6 progress" data-progress-percent6="75">
									  75 %<div class="progress-bar6 progress"></div>

									</div>

									
								</section>
							</div>
						  </div>

							<div class="col-md-6 text wow animated fadeInLeft">
							<div class="item_frame">
								<section>
									<div class="skill_title">jQuery</div>
									<div class="progress-wrap2 progress" data-progress-percent2="90">
									90 %  <div class="progress-bar2 progress"></div>

									</div>

									
								</section>
							</div>
						  </div>

						  <div class="col-md-6 text wow animated fadeInRight">
							<div class="item_frame">
								<section>
									<div class="skill_title">HTML5</div>
									<div class="progress-wrap3 progress" data-progress-percent3="85">
									  85 %<div class="progress-bar3 progress"></div>

									</div>

									
								</section>
							</div>
						  </div>

							<div class="col-md-6 text wow animated fadeInLeft">
							<div class="item_frame">
								<section>
									<div class="skill_title">Graphic Design</div>
									<div class="progress-wrap4 progress" data-progress-percent4="80">
									  80 %<div class="progress-bar4 progress"></div>

									</div>

									
								</section>
							</div>
						  </div>
                          
                         <div class="col-md-6 text wow animated fadeInRight">
							<div class="item_frame">
								<section>
									<div class="skill_title">CSS</div>
									<div class="progress-wrap5 progress" data-progress-percent5="95">
									  95 %<div class="progress-bar5 progress"></div>

									</div>

									
								</section>
							</div>
						  </div>
                          
                          


						</div>
						
					</div>
</section>